#include <cstdlib>

int main()
{
    system("gnome-terminal -- bash -c ' export GAZEBO_PLUGIN_PATH=`pwd`:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_PLUGIN_PATH=~/projet/Optimization_GUI_interface/build:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_PLUGIN_PATH=~/projet/print_sensor_info/build:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_PLUGIN_PATH=~/projet/sensor_optimization/build:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_PLUGIN_PATH=~/projet/board_placement/build:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_PLUGIN_PATH=~/projet/calculate/build:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_PLUGIN_PATH=~/catkin_ws/src/livox_laser_simulation/build/devel/lib:$GAZEBO_PLUGIN_PATH\
     && export GAZEBO_RENDERING_QUALITY=1 && gazebo ori.world --verbose; exec bash'");
    return 0;
}