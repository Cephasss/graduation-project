
Modify the cpp code "init.cpp" to correctly export your file path.
You can also change the world name in "gazebo ori.world" to load different initial world.
Finally, compile the "init.cpp" and start Gazebo.
