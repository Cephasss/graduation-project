Put the files into "your_install_location/.gazebo/models".
