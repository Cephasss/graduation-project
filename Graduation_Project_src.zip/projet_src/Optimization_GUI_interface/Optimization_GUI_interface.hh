#ifndef _GUI_OPT
#define _GUI_OPT

#include <gazebo/common/Plugin.hh>
#include <gazebo/gui/GuiPlugin.hh>
#include <gazebo/common/common.hh>

#ifndef Q_MOC_RUN
#include <gazebo/transport/transport.hh>
#include <gazebo/gui/GuiEvents.hh>
#endif

class MyDialog : public QDialog {
    Q_OBJECT

public:
    MyDialog(QWidget* parent = nullptr);
    public: bool new_save;

public slots:
    void onButtonClicked();


    public:
        bool cover;
        bool redun;
        int n_solu;
        int opt_turns;
        double pro_cross;
        double pro_mut;
        double adap_factor;
        double max_angle;
        double min_angle;
        bool init;
};

namespace gazebo
{
    class GAZEBO_VISIBLE Optimization_GUI_interface : public GUIPlugin
    {
      Q_OBJECT

      public: Optimization_GUI_interface();

      public: virtual ~Optimization_GUI_interface();

      protected slots: void OnButton1();
      protected slots: void OnButton2();
      protected slots: void OnButton3();
      protected slots: void OnButton4();

      public: void OnStats(ConstWorldStatisticsPtr &_msg);

      public: void Subtopic(ConstParam_VPtr &_msg);

      public: bool ifsub;

      private: unsigned int counter;

      private: transport::NodePtr node;

      private: transport::PublisherPtr factoryPub;

      private: transport::SubscriberPtr statsSub;

      private: transport::SubscriberPtr statsSub2;

      private: event::ConnectionPtr updateTimer;

      private:
        bool cover;
        bool redun;
        int n_solu;
        int opt_turns;
        double pro_cross;
        double pro_mut;
        double adap_factor;
        double max_yaw_angle;
        double min_yaw_angle;
    };
}
#endif
